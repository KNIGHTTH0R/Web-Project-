-- phpMyAdmin SQL Dump
-- version 3.2.0
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306

-- Generation Time: Aug 06, 2015 at 07:19 AM
-- Server version: 5.1.35
-- PHP Version: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `cse391_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` VALUES(1, 123, 'Fahim');

-- --------------------------------------------------------

--
-- Table structure for table `advice`
--

CREATE TABLE `advice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `info` varchar(500) NOT NULL,
  `advice` varchar(500) NOT NULL,
  `Image_path` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `advice`
--

INSERT INTO `advice` VALUES(1, 'Fahim', 'Geraldine Tan, Interior Writer', '“Don’t be frightened to add colour into your space. It’s not all about painting large walls. Think about accent colours like painting a small area at the back of a shelf or a stool to add visual pops of colour. Decorate with colourful accessories against a neutral backdrop until you feel confident of what your personal colour palette is” Geraldine Tan, Interior Writer', 'Advisors/archetect-on-construction-site.jpg');
INSERT INTO `advice` VALUES(2, 'Tanveer', 'Meg Caswell, Interior Designer', '“Always start with the rug when designing a room. You will only have a few rugs that you fall in love with but there will be dozens of paint colors and fabrics you will love. So start with the rug and then select your paints and fabrics. It makes for a much easier process. You won’t be searching forever for the right rug to fit into the rest of the room and then end up compromising your design because of it”', 'Advisors/bridge-construction.jpg');
INSERT INTO `advice` VALUES(3, 'Sakib', 'Amy Wong, Editorial Assistant at LifestyleETC', 'For an easy way to instantly update the room try a few pieces of brightly coloured or patterned soft furnishings. A statement throw or a few bold cushions can really change the feel of a space, and are a great way to keep up with the latest interiors trends without making a big investment”', 'Advisors/engineer615.jpg');
INSERT INTO `advice` VALUES(4, 'Jack', 'Shai DeLuca-Tamasi, Interior Designer', '“The best design advice I can give is three fold. First, always remember to layer a space. Even the most expensive design concepts look unfinished when visually flat.  Second, like my company motto states, “Life is in the details, style accordingly”. A successfully designed space should be planned down to the smallest of details. And finally, always make your design choices look intentional. Even when faced with a challenging space, incorporate the challenges into your design rather than trying ', 'Advisors/How-To-Become-A-Software-EngineerSoftware-Engineera.jpg');
INSERT INTO `advice` VALUES(5, 'Mike', 'Melanie Langford, Interior Designer', '“Do NOT listen to neighbour’s, friends or family for decorating advice. Everyone has an opinion they think is best and will often offer theirs. However, each person has their own style that may or may not match yours, figure out what works best for your lifestyle and then hire a professional, experienced decorator to pull it all together so that it makes sense and works”', 'Advisors/man-in-hardhat.jpg');
INSERT INTO `advice` VALUES(6, 'Fahim', 'Geraldine Tan, Interior Writer', '“Don’t be frightened to add colour into your space. It’s not all about painting large walls. Think about accent colours like painting a small area at the back of a shelf or a stool to add visual pops of colour. Decorate with colourful accessories against a neutral backdrop until you feel confident of what your personal colour palette is” Geraldine Tan, Interior Writer', 'Advisors/portrait-of-an-enginee.jpg');
INSERT INTO `advice` VALUES(7, 'Rozin', 'Meg Caswell, Interior Designer', '“Always start with the rug when designing a room. You will only have a few rugs that you fall in love with but there will be dozens of paint colors and fabrics you will love. So start with the rug and then select your paints and fabrics. It makes for a much easier process. You won’t be searching forever for the right rug to fit into the rest of the room and then end up compromising your design because of it”', 'Advisors/mechanical-engineer.jpg');
INSERT INTO `advice` VALUES(8, 'Shafiqul', 'Amy Wong, Editorial Assistant at LifestyleETC', 'For an easy way to instantly update the room try a few pieces of brightly coloured or patterned soft furnishings. A statement throw or a few bold cushions can really change the feel of a space, and are a great way to keep up with the latest interiors trends without making a big investment”', 'Advisors/People_Interior_Designers_Carousel_Massimo-980x550.jpg');
INSERT INTO `advice` VALUES(9, 'Jack', 'Shai DeLuca-Tamasi, Interior Designer', '“The best design advice I can give is three fold. First, always remember to layer a space. Even the most expensive design concepts look unfinished when visually flat.  Second, like my company motto states, “Life is in the details, style accordingly”. A successfully designed space should be planned down to the smallest of details. And finally, always make your design choices look intentional. Even when faced with a challenging space, incorporate the challenges into your design rather than trying ', 'Advisors/warby-parkers-founder-there-are-2-reasons-why-people-leave-their-jobs.jpg');
INSERT INTO `advice` VALUES(10, 'Mike', 'Melanie Langford, Interior Designer', '“Do NOT listen to neighbour’s, friends or family for decorating advice. Everyone has an opinion they think is best and will often offer theirs. However, each person has their own style that may or may not match yours, figure out what works best for your lifestyle and then hire a professional, experienced decorator to pull it all together so that it makes sense and works”', 'Advisors/what_is_engineering.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `Product_Description` varchar(500) NOT NULL,
  `Product_Cost` int(20) NOT NULL,
  `Product_Type` varchar(500) NOT NULL,
  `Product_Status` varchar(500) NOT NULL,
  `Product_ImagePath` varchar(500) NOT NULL,
  `Product_Warranty` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` VALUES(1, 'Woodgrove 43" White Wash Wood Barstool With Leatherette Seat', 'Style your home with this inviting barstool from the CorLiving Collection. This barstool is the perfect way to relax indoors at a 38"- 41" counter height bar. An easy to wipe clean, tough White Leatherette seat is highlighted with a padded White Leatherette backrest and a sturdy white wash wood base', 342, 'kitchen', 'Availabe', 'Kitchen and Dining/transitional-dining-chairs.jpg', 'NO');
INSERT INTO `articles` VALUES(2, ' Mocha 41" High Counter Height Dining Chair', 'These mocha 41" high counter dining chairs accentuate the table with their stylish criss-cross design. These leather-look chairs are exquisitely cushioned for your utmost comfort. They undeniably add style and appeal to this unique dining set.', 435, 'kitchen', 'Availabe', 'Kitchen and Dining/woodenchairs.jpg', '3 years');
INSERT INTO `articles` VALUES(3, 'Chelsea Stools With Upholstered Seat', 'FEATURES: The well-crafted counter stools boast style and comfort with charming fluted legs and supportive stretchers for footrests. The slat-back stools for your comfort. Pub counter height chair is built to last with durable hardwood, tastefully finished in a rich Mahogany finish . Dining room counter stools constructed of all hardwood. Dining stool comes with solid cushion seat.', 657, 'kitchen', 'Availabe', 'Kitchen and Dining/traditional-dining-chairs.jpg', 'NO');
INSERT INTO `articles` VALUES(5, 'Stainless Steel Commercial Spring Kitchen Faucet With Pull Down Shower Spray', 'Solid Stainless Steel Commercial Spring Kitchen Faucet With Pull Down Shower Spray  LEON kitchen faucets by ALFI brand are made of solid stainless steel, unlike traditional faucets which are made out of brass and treated to created different finishes. These faucets are built tough and made to last for decades, both in durability and looks. Product Specifications', 123, 'kitchen', 'Availabe', 'Kitchen and Dining/Faucet.jpg', 'asdsadsad');
INSERT INTO `articles` VALUES(7, 'Ocean Cliff', 'This is an example of a beach style living room in Portland Maine with white walls, medium tone hardwood floors and a standard fireplace', 324, 'sofasandchairs', 'Availabe', 'Sofas and chairs/Ocean cliff.jpg', '3 years');
INSERT INTO `articles` VALUES(8, 'Tupper Lake Residence', 'Inspiration for a farmhouse kitchen in Houston with a kitchen/dining combo, shaker cabinets, gray cabinets, stainless steel appliances and medium tone hardwood floors.', 232, 'homedecoration', 'Available', 'Home decoration/Home Decoration 5.jpg', '3 years');
INSERT INTO `articles` VALUES(9, ' Coronado Renovation', 'Design ideas for a contemporary galley kitchen in Phoenix with a kitchen/dining combo, an undermount sink, flat-panel cabinets, dark wood cabinets, black appliances, light hardwood floors and an island', 232, 'kitchen', 'Availabe', 'Kitchen and Dining/Coronadorenovation.jpg', ' 3 years');
INSERT INTO `articles` VALUES(10, 'Jupiter Remodel', 'Photo of a transitional kitchen in Miami with an undermount sink, recessed-panel cabinets, white cabinets, granite countertops, beige backsplash, matchstick tile backsplash, stainless steel appliances, ceramic floors and an island', 121, 'homedecoration', 'Avialable', 'Home decoration/Jupiter model.jpg', '3 years');
INSERT INTO `articles` VALUES(13, 'Pink bed room for Childrens', 'Inspiration for a children bed room in Houston ', 2323, 'homedecoration', 'Available', 'Home decoration/Home Decoration 1.jpg', '3 years');
INSERT INTO `articles` VALUES(14, 'Elegant bed room', 'Inspiration for a elegant  decoration for bed room ', 213, 'homedecoration', 'Available', 'Home decoration/Home Decoration 2.jpg', '3 years');
INSERT INTO `articles` VALUES(15, 'Beautiful Farm house chairs for relaxation ', 'Inspiration for a outdoor decoration in a farmhouse', 234, 'homedecoration', 'Available', 'Home decoration/Home Decoration 3.jpg', '3 years');
INSERT INTO `articles` VALUES(16, 'Elegant kitchen design', 'Inspiration for a kitchen decoration in  modern houses', 213, 'homedecoration', 'Available', 'Home decoration/Home Decoration 4.jpg', '3 years');
INSERT INTO `articles` VALUES(17, 'Black  living lounge sofas and chairs', 'Contemporary-black-lounge-chairs-and-floor-lamp-also-laminate-flooring-and-wood-chair', 123, 'sofasandchairs', 'Availabe', 'Sofas and chairs/Contemporary-black-lounge-chairs-and-floor-lamp-also-laminate-flooring-and-wood-chair.jpeg', 'NO');
INSERT INTO `articles` VALUES(18, 'kitchen  chairs for diner lounge', 'kitchen-diner-lounge-stylish-formal-dining-room-with-stylish-dining-table-and-chairs-also-grey-comfy-sofa-and-open-shelve-ideas-plus-hardwood-flooring-and-grey-wall-features-with-unique-curt', 123, 'sofasandchairs', 'Available', 'Sofas and chairs/kitchen-diner-lounge-stylish-formal-dining-room-with-stylish-dining-table.jpeg', 'NO');
INSERT INTO `articles` VALUES(19, 'Elegant chairs for living room', 'minimalist-living-room-with-classic-grey-sofa-and-chairs', 324, 'sofasandchairs', 'Available', 'Sofas and chairs/minimalist-living-room-with-classic-grey-sofa-and-chairs.jpg', 'NO');
INSERT INTO `articles` VALUES(20, 'Modern interior ideas for living room', 'Modern-contemporary-open-floor-designs-ideas', 454, 'sofasandchairs', 'Available', 'Sofas and chairs/Modern-contemporary-open-floor-designs-ideas-with-white.jpg', 'NO');
INSERT INTO `articles` VALUES(21, 'Papay Residence', 'Inspiration for a large transitional master bedroom in Denver with white walls and carpet. ', 453, 'bedsandhardbord', 'Availabe', 'Beds and hardboard/PaypayResidence.jpg', 'NO');
INSERT INTO `articles` VALUES(22, '2014 Interior Design Excellence Awards – Arent&Pyke ''The Avenue''', 'Design of a contemporary master bedroom with blue walls and dark hardwood floors', 345, 'bedsandhardbord', 'Available', 'Beds and hardboard/ArentandPyke.jpg', 'NO');
INSERT INTO `articles` VALUES(23, 'Future Bed for modern homes', 'Wooden-Headboard-Bed-Furniture-Design-by-Cliff-Young-NYC', 456, 'bedsandhardbord', 'Available', 'Beds and hardboard/Wooden-Beds-Headboards-Storage-Design-1-Modern-World-Home-Interior-Modern-Wood-Beds.jpg', 'NO');
INSERT INTO `articles` VALUES(24, 'Future Bed for modern homes', 'Wooden-Headboard-Bed-Furniture-Design-by-Cliff-Young-NYC', 234, 'bedsandhardbord', 'Availabe', 'Beds and hardboard/Wooden-Headboard-Bed-Furniture-Design-by-Cliff-Young-NYC.jpg', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `articles_ratings`
--

CREATE TABLE `articles_ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `articles` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=434 ;

--
-- Dumping data for table `articles_ratings`
--

INSERT INTO `articles_ratings` VALUES(1, 2, 4);
INSERT INTO `articles_ratings` VALUES(2, 3, 4);
INSERT INTO `articles_ratings` VALUES(3, 3, 5);
INSERT INTO `articles_ratings` VALUES(4, 3, 5);
INSERT INTO `articles_ratings` VALUES(5, 3, 2);
INSERT INTO `articles_ratings` VALUES(6, 3, 5);
INSERT INTO `articles_ratings` VALUES(7, 3, 5);
INSERT INTO `articles_ratings` VALUES(8, 3, 5);
INSERT INTO `articles_ratings` VALUES(9, 3, 3);
INSERT INTO `articles_ratings` VALUES(10, 3, 1);
INSERT INTO `articles_ratings` VALUES(11, 3, 4);
INSERT INTO `articles_ratings` VALUES(12, 3, 5);
INSERT INTO `articles_ratings` VALUES(13, 1, 5);
INSERT INTO `articles_ratings` VALUES(14, 1, 5);
INSERT INTO `articles_ratings` VALUES(15, 2, 5);
INSERT INTO `articles_ratings` VALUES(16, 2, 5);
INSERT INTO `articles_ratings` VALUES(17, 3, 5);
INSERT INTO `articles_ratings` VALUES(18, 3, 5);
INSERT INTO `articles_ratings` VALUES(19, 3, 5);
INSERT INTO `articles_ratings` VALUES(20, 3, 3);
INSERT INTO `articles_ratings` VALUES(21, 3, 3);
INSERT INTO `articles_ratings` VALUES(22, 3, 2);
INSERT INTO `articles_ratings` VALUES(23, 3, 5);
INSERT INTO `articles_ratings` VALUES(24, 2, 3);
INSERT INTO `articles_ratings` VALUES(25, 3, 2);
INSERT INTO `articles_ratings` VALUES(26, 1, 3);
INSERT INTO `articles_ratings` VALUES(27, 1, 3);
INSERT INTO `articles_ratings` VALUES(28, 1, 3);
INSERT INTO `articles_ratings` VALUES(29, 1, 5);
INSERT INTO `articles_ratings` VALUES(30, 1, 5);
INSERT INTO `articles_ratings` VALUES(31, 3, 5);
INSERT INTO `articles_ratings` VALUES(32, 3, 5);
INSERT INTO `articles_ratings` VALUES(33, 3, 5);
INSERT INTO `articles_ratings` VALUES(34, 3, 5);
INSERT INTO `articles_ratings` VALUES(35, 2, 2);
INSERT INTO `articles_ratings` VALUES(36, 1, 1);
INSERT INTO `articles_ratings` VALUES(37, 1, 5);
INSERT INTO `articles_ratings` VALUES(38, 1, 2);
INSERT INTO `articles_ratings` VALUES(39, 1, 5);
INSERT INTO `articles_ratings` VALUES(40, 1, 2);
INSERT INTO `articles_ratings` VALUES(41, 3, 5);
INSERT INTO `articles_ratings` VALUES(42, 3, 4);
INSERT INTO `articles_ratings` VALUES(43, 3, 5);
INSERT INTO `articles_ratings` VALUES(44, 3, 5);
INSERT INTO `articles_ratings` VALUES(45, 3, 5);
INSERT INTO `articles_ratings` VALUES(46, 1, 1);
INSERT INTO `articles_ratings` VALUES(47, 1, 1);
INSERT INTO `articles_ratings` VALUES(48, 1, 5);
INSERT INTO `articles_ratings` VALUES(49, 1, 5);
INSERT INTO `articles_ratings` VALUES(50, 1, 5);
INSERT INTO `articles_ratings` VALUES(51, 1, 5);
INSERT INTO `articles_ratings` VALUES(52, 1, 5);
INSERT INTO `articles_ratings` VALUES(53, 1, 5);
INSERT INTO `articles_ratings` VALUES(54, 1, 5);
INSERT INTO `articles_ratings` VALUES(55, 1, 5);
INSERT INTO `articles_ratings` VALUES(56, 1, 5);
INSERT INTO `articles_ratings` VALUES(57, 1, 5);
INSERT INTO `articles_ratings` VALUES(58, 1, 5);
INSERT INTO `articles_ratings` VALUES(59, 1, 2);
INSERT INTO `articles_ratings` VALUES(60, 1, 5);
INSERT INTO `articles_ratings` VALUES(61, 1, 5);
INSERT INTO `articles_ratings` VALUES(62, 1, 5);
INSERT INTO `articles_ratings` VALUES(63, 1, 5);
INSERT INTO `articles_ratings` VALUES(64, 1, 5);
INSERT INTO `articles_ratings` VALUES(65, 1, 5);
INSERT INTO `articles_ratings` VALUES(66, 1, 5);
INSERT INTO `articles_ratings` VALUES(67, 1, 5);
INSERT INTO `articles_ratings` VALUES(68, 1, 5);
INSERT INTO `articles_ratings` VALUES(69, 1, 5);
INSERT INTO `articles_ratings` VALUES(70, 1, 5);
INSERT INTO `articles_ratings` VALUES(71, 1, 5);
INSERT INTO `articles_ratings` VALUES(72, 1, 5);
INSERT INTO `articles_ratings` VALUES(73, 1, 5);
INSERT INTO `articles_ratings` VALUES(74, 1, 5);
INSERT INTO `articles_ratings` VALUES(75, 1, 5);
INSERT INTO `articles_ratings` VALUES(76, 1, 5);
INSERT INTO `articles_ratings` VALUES(77, 2, 1);
INSERT INTO `articles_ratings` VALUES(78, 2, 5);
INSERT INTO `articles_ratings` VALUES(79, 2, 5);
INSERT INTO `articles_ratings` VALUES(80, 2, 4);
INSERT INTO `articles_ratings` VALUES(81, 2, 4);
INSERT INTO `articles_ratings` VALUES(82, 2, 2);
INSERT INTO `articles_ratings` VALUES(83, 2, 1);
INSERT INTO `articles_ratings` VALUES(84, 2, 2);
INSERT INTO `articles_ratings` VALUES(85, 2, 3);
INSERT INTO `articles_ratings` VALUES(86, 2, 4);
INSERT INTO `articles_ratings` VALUES(87, 2, 4);
INSERT INTO `articles_ratings` VALUES(88, 2, 4);
INSERT INTO `articles_ratings` VALUES(89, 2, 4);
INSERT INTO `articles_ratings` VALUES(90, 2, 4);
INSERT INTO `articles_ratings` VALUES(91, 2, 4);
INSERT INTO `articles_ratings` VALUES(92, 2, 4);
INSERT INTO `articles_ratings` VALUES(93, 2, 4);
INSERT INTO `articles_ratings` VALUES(94, 2, 4);
INSERT INTO `articles_ratings` VALUES(95, 2, 4);
INSERT INTO `articles_ratings` VALUES(96, 2, 4);
INSERT INTO `articles_ratings` VALUES(97, 2, 4);
INSERT INTO `articles_ratings` VALUES(98, 2, 4);
INSERT INTO `articles_ratings` VALUES(99, 2, 4);
INSERT INTO `articles_ratings` VALUES(100, 2, 3);
INSERT INTO `articles_ratings` VALUES(194, 3, 5);
INSERT INTO `articles_ratings` VALUES(193, 3, 5);
INSERT INTO `articles_ratings` VALUES(192, 3, 2);
INSERT INTO `articles_ratings` VALUES(191, 3, 2);
INSERT INTO `articles_ratings` VALUES(190, 3, 2);
INSERT INTO `articles_ratings` VALUES(189, 3, 2);
INSERT INTO `articles_ratings` VALUES(188, 3, 2);
INSERT INTO `articles_ratings` VALUES(187, 3, 2);
INSERT INTO `articles_ratings` VALUES(186, 3, 2);
INSERT INTO `articles_ratings` VALUES(185, 3, 3);
INSERT INTO `articles_ratings` VALUES(184, 3, 3);
INSERT INTO `articles_ratings` VALUES(183, 3, 3);
INSERT INTO `articles_ratings` VALUES(182, 3, 3);
INSERT INTO `articles_ratings` VALUES(167, 3, 4);
INSERT INTO `articles_ratings` VALUES(181, 3, 3);
INSERT INTO `articles_ratings` VALUES(180, 3, 3);
INSERT INTO `articles_ratings` VALUES(179, 3, 3);
INSERT INTO `articles_ratings` VALUES(178, 3, 3);
INSERT INTO `articles_ratings` VALUES(177, 3, 3);
INSERT INTO `articles_ratings` VALUES(176, 3, 3);
INSERT INTO `articles_ratings` VALUES(175, 3, 3);
INSERT INTO `articles_ratings` VALUES(174, 3, 3);
INSERT INTO `articles_ratings` VALUES(173, 3, 3);
INSERT INTO `articles_ratings` VALUES(172, 3, 3);
INSERT INTO `articles_ratings` VALUES(171, 3, 4);
INSERT INTO `articles_ratings` VALUES(170, 3, 4);
INSERT INTO `articles_ratings` VALUES(169, 3, 4);
INSERT INTO `articles_ratings` VALUES(168, 3, 4);
INSERT INTO `articles_ratings` VALUES(166, 3, 4);
INSERT INTO `articles_ratings` VALUES(165, 3, 4);
INSERT INTO `articles_ratings` VALUES(132, 1, 5);
INSERT INTO `articles_ratings` VALUES(133, 1, 3);
INSERT INTO `articles_ratings` VALUES(134, 1, 1);
INSERT INTO `articles_ratings` VALUES(135, 1, 1);
INSERT INTO `articles_ratings` VALUES(136, 1, 1);
INSERT INTO `articles_ratings` VALUES(137, 3, 5);
INSERT INTO `articles_ratings` VALUES(138, 3, 5);
INSERT INTO `articles_ratings` VALUES(139, 3, 5);
INSERT INTO `articles_ratings` VALUES(140, 3, 5);
INSERT INTO `articles_ratings` VALUES(153, 3, 4);
INSERT INTO `articles_ratings` VALUES(154, 3, 4);
INSERT INTO `articles_ratings` VALUES(155, 3, 4);
INSERT INTO `articles_ratings` VALUES(156, 3, 4);
INSERT INTO `articles_ratings` VALUES(157, 3, 4);
INSERT INTO `articles_ratings` VALUES(158, 3, 4);
INSERT INTO `articles_ratings` VALUES(159, 3, 4);
INSERT INTO `articles_ratings` VALUES(160, 3, 4);
INSERT INTO `articles_ratings` VALUES(161, 3, 4);
INSERT INTO `articles_ratings` VALUES(162, 3, 4);
INSERT INTO `articles_ratings` VALUES(163, 3, 4);
INSERT INTO `articles_ratings` VALUES(164, 3, 4);
INSERT INTO `articles_ratings` VALUES(195, 3, 5);
INSERT INTO `articles_ratings` VALUES(196, 3, 5);
INSERT INTO `articles_ratings` VALUES(197, 3, 5);
INSERT INTO `articles_ratings` VALUES(198, 3, 5);
INSERT INTO `articles_ratings` VALUES(199, 3, 5);
INSERT INTO `articles_ratings` VALUES(200, 3, 5);
INSERT INTO `articles_ratings` VALUES(201, 3, 5);
INSERT INTO `articles_ratings` VALUES(202, 3, 5);
INSERT INTO `articles_ratings` VALUES(203, 3, 5);
INSERT INTO `articles_ratings` VALUES(204, 3, 1);
INSERT INTO `articles_ratings` VALUES(205, 3, 1);
INSERT INTO `articles_ratings` VALUES(206, 3, 1);
INSERT INTO `articles_ratings` VALUES(207, 3, 1);
INSERT INTO `articles_ratings` VALUES(208, 3, 1);
INSERT INTO `articles_ratings` VALUES(209, 3, 1);
INSERT INTO `articles_ratings` VALUES(210, 3, 1);
INSERT INTO `articles_ratings` VALUES(211, 3, 1);
INSERT INTO `articles_ratings` VALUES(212, 3, 1);
INSERT INTO `articles_ratings` VALUES(213, 3, 1);
INSERT INTO `articles_ratings` VALUES(214, 3, 1);
INSERT INTO `articles_ratings` VALUES(215, 3, 1);
INSERT INTO `articles_ratings` VALUES(216, 3, 1);
INSERT INTO `articles_ratings` VALUES(217, 3, 1);
INSERT INTO `articles_ratings` VALUES(218, 3, 1);
INSERT INTO `articles_ratings` VALUES(219, 3, 1);
INSERT INTO `articles_ratings` VALUES(220, 3, 1);
INSERT INTO `articles_ratings` VALUES(221, 3, 1);
INSERT INTO `articles_ratings` VALUES(222, 3, 1);
INSERT INTO `articles_ratings` VALUES(223, 3, 1);
INSERT INTO `articles_ratings` VALUES(224, 3, 1);
INSERT INTO `articles_ratings` VALUES(225, 3, 1);
INSERT INTO `articles_ratings` VALUES(226, 3, 2);
INSERT INTO `articles_ratings` VALUES(227, 3, 2);
INSERT INTO `articles_ratings` VALUES(228, 3, 2);
INSERT INTO `articles_ratings` VALUES(229, 3, 2);
INSERT INTO `articles_ratings` VALUES(230, 3, 2);
INSERT INTO `articles_ratings` VALUES(231, 3, 2);
INSERT INTO `articles_ratings` VALUES(232, 3, 2);
INSERT INTO `articles_ratings` VALUES(233, 3, 2);
INSERT INTO `articles_ratings` VALUES(234, 3, 2);
INSERT INTO `articles_ratings` VALUES(235, 3, 2);
INSERT INTO `articles_ratings` VALUES(236, 3, 3);
INSERT INTO `articles_ratings` VALUES(237, 3, 3);
INSERT INTO `articles_ratings` VALUES(238, 3, 3);
INSERT INTO `articles_ratings` VALUES(239, 3, 3);
INSERT INTO `articles_ratings` VALUES(240, 3, 3);
INSERT INTO `articles_ratings` VALUES(241, 3, 3);
INSERT INTO `articles_ratings` VALUES(242, 3, 3);
INSERT INTO `articles_ratings` VALUES(243, 3, 3);
INSERT INTO `articles_ratings` VALUES(244, 3, 3);
INSERT INTO `articles_ratings` VALUES(245, 3, 3);
INSERT INTO `articles_ratings` VALUES(246, 3, 3);
INSERT INTO `articles_ratings` VALUES(247, 3, 3);
INSERT INTO `articles_ratings` VALUES(248, 3, 3);
INSERT INTO `articles_ratings` VALUES(249, 3, 3);
INSERT INTO `articles_ratings` VALUES(250, 3, 3);
INSERT INTO `articles_ratings` VALUES(251, 3, 3);
INSERT INTO `articles_ratings` VALUES(252, 3, 4);
INSERT INTO `articles_ratings` VALUES(253, 3, 4);
INSERT INTO `articles_ratings` VALUES(254, 3, 4);
INSERT INTO `articles_ratings` VALUES(255, 3, 4);
INSERT INTO `articles_ratings` VALUES(256, 3, 4);
INSERT INTO `articles_ratings` VALUES(257, 3, 4);
INSERT INTO `articles_ratings` VALUES(258, 3, 4);
INSERT INTO `articles_ratings` VALUES(259, 3, 4);
INSERT INTO `articles_ratings` VALUES(260, 3, 5);
INSERT INTO `articles_ratings` VALUES(261, 3, 5);
INSERT INTO `articles_ratings` VALUES(262, 3, 5);
INSERT INTO `articles_ratings` VALUES(273, 1, 4);
INSERT INTO `articles_ratings` VALUES(274, 1, 3);
INSERT INTO `articles_ratings` VALUES(275, 1, 2);
INSERT INTO `articles_ratings` VALUES(276, 1, 4);
INSERT INTO `articles_ratings` VALUES(277, 1, 3);
INSERT INTO `articles_ratings` VALUES(278, 1, 1);
INSERT INTO `articles_ratings` VALUES(279, 1, 1);
INSERT INTO `articles_ratings` VALUES(280, 1, 5);
INSERT INTO `articles_ratings` VALUES(281, 1, 5);
INSERT INTO `articles_ratings` VALUES(282, 1, 5);
INSERT INTO `articles_ratings` VALUES(283, 1, 5);
INSERT INTO `articles_ratings` VALUES(284, 1, 5);
INSERT INTO `articles_ratings` VALUES(285, 1, 5);
INSERT INTO `articles_ratings` VALUES(286, 1, 5);
INSERT INTO `articles_ratings` VALUES(287, 1, 5);
INSERT INTO `articles_ratings` VALUES(288, 5, NULL);
INSERT INTO `articles_ratings` VALUES(289, 7, NULL);
INSERT INTO `articles_ratings` VALUES(290, 8, NULL);
INSERT INTO `articles_ratings` VALUES(291, 9, NULL);
INSERT INTO `articles_ratings` VALUES(292, 5, 5);
INSERT INTO `articles_ratings` VALUES(293, 5, 4);
INSERT INTO `articles_ratings` VALUES(294, 5, 4);
INSERT INTO `articles_ratings` VALUES(295, 5, 4);
INSERT INTO `articles_ratings` VALUES(296, 5, 4);
INSERT INTO `articles_ratings` VALUES(297, 5, 4);
INSERT INTO `articles_ratings` VALUES(298, 5, 4);
INSERT INTO `articles_ratings` VALUES(299, 5, 4);
INSERT INTO `articles_ratings` VALUES(300, 5, 4);
INSERT INTO `articles_ratings` VALUES(301, 5, 3);
INSERT INTO `articles_ratings` VALUES(302, 5, 3);
INSERT INTO `articles_ratings` VALUES(303, 5, 3);
INSERT INTO `articles_ratings` VALUES(304, 5, 3);
INSERT INTO `articles_ratings` VALUES(305, 5, 3);
INSERT INTO `articles_ratings` VALUES(306, 5, 3);
INSERT INTO `articles_ratings` VALUES(307, 5, 3);
INSERT INTO `articles_ratings` VALUES(308, 5, 3);
INSERT INTO `articles_ratings` VALUES(309, 5, 3);
INSERT INTO `articles_ratings` VALUES(310, 5, 3);
INSERT INTO `articles_ratings` VALUES(311, 5, 2);
INSERT INTO `articles_ratings` VALUES(312, 5, 2);
INSERT INTO `articles_ratings` VALUES(313, 5, 2);
INSERT INTO `articles_ratings` VALUES(314, 5, 2);
INSERT INTO `articles_ratings` VALUES(315, 5, 2);
INSERT INTO `articles_ratings` VALUES(316, 5, 2);
INSERT INTO `articles_ratings` VALUES(317, 5, 2);
INSERT INTO `articles_ratings` VALUES(318, 5, 2);
INSERT INTO `articles_ratings` VALUES(319, 5, 2);
INSERT INTO `articles_ratings` VALUES(320, 5, 3);
INSERT INTO `articles_ratings` VALUES(321, 5, 3);
INSERT INTO `articles_ratings` VALUES(322, 5, 3);
INSERT INTO `articles_ratings` VALUES(323, 5, 3);
INSERT INTO `articles_ratings` VALUES(324, 5, 3);
INSERT INTO `articles_ratings` VALUES(325, 5, 3);
INSERT INTO `articles_ratings` VALUES(326, 5, 3);
INSERT INTO `articles_ratings` VALUES(327, 5, 3);
INSERT INTO `articles_ratings` VALUES(328, 5, 3);
INSERT INTO `articles_ratings` VALUES(329, 5, 3);
INSERT INTO `articles_ratings` VALUES(330, 5, 3);
INSERT INTO `articles_ratings` VALUES(331, 5, 4);
INSERT INTO `articles_ratings` VALUES(332, 5, 4);
INSERT INTO `articles_ratings` VALUES(333, 5, 4);
INSERT INTO `articles_ratings` VALUES(334, 5, 4);
INSERT INTO `articles_ratings` VALUES(335, 5, 4);
INSERT INTO `articles_ratings` VALUES(336, 5, 4);
INSERT INTO `articles_ratings` VALUES(337, 5, 4);
INSERT INTO `articles_ratings` VALUES(338, 5, 4);
INSERT INTO `articles_ratings` VALUES(339, 5, 4);
INSERT INTO `articles_ratings` VALUES(340, 5, 4);
INSERT INTO `articles_ratings` VALUES(341, 5, 4);
INSERT INTO `articles_ratings` VALUES(342, 5, 4);
INSERT INTO `articles_ratings` VALUES(343, 5, 4);
INSERT INTO `articles_ratings` VALUES(344, 5, 4);
INSERT INTO `articles_ratings` VALUES(345, 5, 5);
INSERT INTO `articles_ratings` VALUES(346, 5, 5);
INSERT INTO `articles_ratings` VALUES(347, 5, 5);
INSERT INTO `articles_ratings` VALUES(348, 5, 5);
INSERT INTO `articles_ratings` VALUES(349, 5, 5);
INSERT INTO `articles_ratings` VALUES(350, 5, 5);
INSERT INTO `articles_ratings` VALUES(351, 5, 5);
INSERT INTO `articles_ratings` VALUES(352, 5, 5);
INSERT INTO `articles_ratings` VALUES(353, 5, 5);
INSERT INTO `articles_ratings` VALUES(354, 5, 5);
INSERT INTO `articles_ratings` VALUES(355, 5, 5);
INSERT INTO `articles_ratings` VALUES(356, 5, 4);
INSERT INTO `articles_ratings` VALUES(357, 5, 5);
INSERT INTO `articles_ratings` VALUES(358, 5, 5);
INSERT INTO `articles_ratings` VALUES(359, 5, 5);
INSERT INTO `articles_ratings` VALUES(360, 5, 4);
INSERT INTO `articles_ratings` VALUES(361, 5, 4);
INSERT INTO `articles_ratings` VALUES(362, 5, 4);
INSERT INTO `articles_ratings` VALUES(363, 5, 4);
INSERT INTO `articles_ratings` VALUES(364, 5, 4);
INSERT INTO `articles_ratings` VALUES(365, 5, 4);
INSERT INTO `articles_ratings` VALUES(366, 5, 4);
INSERT INTO `articles_ratings` VALUES(367, 5, 4);
INSERT INTO `articles_ratings` VALUES(368, 5, 3);
INSERT INTO `articles_ratings` VALUES(369, 5, 3);
INSERT INTO `articles_ratings` VALUES(370, 5, 3);
INSERT INTO `articles_ratings` VALUES(371, 5, 3);
INSERT INTO `articles_ratings` VALUES(372, 5, 3);
INSERT INTO `articles_ratings` VALUES(373, 5, 3);
INSERT INTO `articles_ratings` VALUES(374, 5, 3);
INSERT INTO `articles_ratings` VALUES(375, 5, 3);
INSERT INTO `articles_ratings` VALUES(376, 5, 3);
INSERT INTO `articles_ratings` VALUES(377, 5, 3);
INSERT INTO `articles_ratings` VALUES(378, 5, 3);
INSERT INTO `articles_ratings` VALUES(379, 5, 3);
INSERT INTO `articles_ratings` VALUES(380, 5, 3);
INSERT INTO `articles_ratings` VALUES(381, 5, 3);
INSERT INTO `articles_ratings` VALUES(382, 5, 3);
INSERT INTO `articles_ratings` VALUES(383, 5, 3);
INSERT INTO `articles_ratings` VALUES(384, 5, 3);
INSERT INTO `articles_ratings` VALUES(385, 5, 3);
INSERT INTO `articles_ratings` VALUES(386, 5, 3);
INSERT INTO `articles_ratings` VALUES(387, 5, 3);
INSERT INTO `articles_ratings` VALUES(388, 5, 3);
INSERT INTO `articles_ratings` VALUES(389, 5, 3);
INSERT INTO `articles_ratings` VALUES(390, 5, 3);
INSERT INTO `articles_ratings` VALUES(391, 5, 3);
INSERT INTO `articles_ratings` VALUES(392, 5, 3);
INSERT INTO `articles_ratings` VALUES(393, 5, 3);
INSERT INTO `articles_ratings` VALUES(394, 5, 3);
INSERT INTO `articles_ratings` VALUES(395, 5, 3);
INSERT INTO `articles_ratings` VALUES(396, 5, 4);
INSERT INTO `articles_ratings` VALUES(397, 5, 4);
INSERT INTO `articles_ratings` VALUES(398, 5, 4);
INSERT INTO `articles_ratings` VALUES(399, 5, 4);
INSERT INTO `articles_ratings` VALUES(400, 5, 4);
INSERT INTO `articles_ratings` VALUES(401, 5, 4);
INSERT INTO `articles_ratings` VALUES(402, 5, 4);
INSERT INTO `articles_ratings` VALUES(403, 5, 4);
INSERT INTO `articles_ratings` VALUES(404, 5, 4);
INSERT INTO `articles_ratings` VALUES(405, 5, 4);
INSERT INTO `articles_ratings` VALUES(406, 5, 5);
INSERT INTO `articles_ratings` VALUES(407, 5, 5);
INSERT INTO `articles_ratings` VALUES(408, 5, 5);
INSERT INTO `articles_ratings` VALUES(409, 5, 5);
INSERT INTO `articles_ratings` VALUES(410, 5, 5);
INSERT INTO `articles_ratings` VALUES(411, 5, 5);
INSERT INTO `articles_ratings` VALUES(412, 5, 5);
INSERT INTO `articles_ratings` VALUES(413, 5, 5);
INSERT INTO `articles_ratings` VALUES(414, 21, NULL);
INSERT INTO `articles_ratings` VALUES(415, 22, NULL);
INSERT INTO `articles_ratings` VALUES(416, 21, NULL);
INSERT INTO `articles_ratings` VALUES(417, 22, NULL);
INSERT INTO `articles_ratings` VALUES(418, 7, NULL);
INSERT INTO `articles_ratings` VALUES(419, 8, NULL);
INSERT INTO `articles_ratings` VALUES(420, 9, NULL);
INSERT INTO `articles_ratings` VALUES(421, 10, NULL);
INSERT INTO `articles_ratings` VALUES(422, 13, NULL);
INSERT INTO `articles_ratings` VALUES(423, 14, NULL);
INSERT INTO `articles_ratings` VALUES(424, 15, NULL);
INSERT INTO `articles_ratings` VALUES(425, 16, NULL);
INSERT INTO `articles_ratings` VALUES(426, 17, NULL);
INSERT INTO `articles_ratings` VALUES(427, 18, NULL);
INSERT INTO `articles_ratings` VALUES(428, 19, NULL);
INSERT INTO `articles_ratings` VALUES(429, 20, NULL);
INSERT INTO `articles_ratings` VALUES(430, 21, NULL);
INSERT INTO `articles_ratings` VALUES(431, 22, NULL);
INSERT INTO `articles_ratings` VALUES(432, 24, NULL);
INSERT INTO `articles_ratings` VALUES(433, 21, 1);

-- --------------------------------------------------------

--
-- Table structure for table `commentbox`
--

CREATE TABLE `commentbox` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) DEFAULT NULL,
  `comment` varchar(500) NOT NULL,
  `article_id` int(11) NOT NULL,
  `checkbox` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_id` (`article_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `commentbox`
--

INSERT INTO `commentbox` VALUES(1, '', 'sdfdfdsfdsfdsf', 1, 1);
INSERT INTO `commentbox` VALUES(2, 'name', 'Halum', 1, 0);
INSERT INTO `commentbox` VALUES(3, 'fdsf', 'dfgfgfdgfdg', 1, 1);
INSERT INTO `commentbox` VALUES(4, 'fdsf', 'sdfsdfdsf', 1, 0);
INSERT INTO `commentbox` VALUES(5, 'fdsf', 'sdfsdfdsf', 1, 0);
INSERT INTO `commentbox` VALUES(6, 'fdsf', 'asdsadsadsad', 1, 1);
INSERT INTO `commentbox` VALUES(7, 'fdsf', 'sdfsdfdsf', 1, 0);
INSERT INTO `commentbox` VALUES(9, 'fdsf', 'sadasdasdasdsa', 1, 0);
INSERT INTO `commentbox` VALUES(10, 'fdsf', 'sadasdasdasdsa', 1, 1);
INSERT INTO `commentbox` VALUES(15, 'sdfdsfsdfsd', 'jkhfhakfhjkdhfjsdhjkfsd', 5, 0);
INSERT INTO `commentbox` VALUES(14, 'sdfdsfsdfsd', 'jkhfhakfhjkdhfjsdhjkfsd', 5, 0);
INSERT INTO `commentbox` VALUES(13, 'sdasd', 'asdasd', 3, 0);
INSERT INTO `commentbox` VALUES(16, 'sdfdsfsdfsd', 'jkhfhakfhjkdhfjsdhjkfsd', 5, 0);
INSERT INTO `commentbox` VALUES(17, 'sdfdsfsdfsd', 'jkhfhakfhjkdhfjsdhjkfsd', 5, 0);
INSERT INTO `commentbox` VALUES(18, 'Rozin', 'hahahahahahsdfdsffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 1);
INSERT INTO `commentbox` VALUES(19, 'Rozin', 'hahahahahahsdfdsffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(20, 'Rozin', 'hahahahahahsdfdsffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(21, '', 'fsfsdfsdfsdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(22, '', 'fsfsdfsdfsdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(23, '', 'fsfsdfsdfsdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(24, '', 'fsfsdfsdfsdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(25, '', 'fsfsdfsdfsdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', 1, 0);
INSERT INTO `commentbox` VALUES(26, '', 'sadsda', 1, 0);
INSERT INTO `commentbox` VALUES(27, '', 'scscscscscscsc', 1, 0);
INSERT INTO `commentbox` VALUES(28, '', 'sdasdsad', 1, 0);
INSERT INTO `commentbox` VALUES(29, '', 'hfhhfhjfh', 1, 0);
INSERT INTO `commentbox` VALUES(30, '', 'asdsadsad', 1, 0);
INSERT INTO `commentbox` VALUES(31, '', 'sasdfsdaf', 1, 0);
INSERT INTO `commentbox` VALUES(32, '', 'sdsad', 1, 0);
INSERT INTO `commentbox` VALUES(33, '', 'adasd', 1, 0);
INSERT INTO `commentbox` VALUES(34, '', 'sdasdsad', 0, 0);
INSERT INTO `commentbox` VALUES(35, '', 'sdgdgdsgdsgdsg', 2, 0);
INSERT INTO `commentbox` VALUES(36, '', 'dsfdfdsf', 9, 0);
INSERT INTO `commentbox` VALUES(37, '', 'dsfdfdsf', 9, 0);
INSERT INTO `commentbox` VALUES(38, '', 'dsfdfdsf', 9, 0);
INSERT INTO `commentbox` VALUES(39, '', 'dfddfhdhfh', 9, 0);
INSERT INTO `commentbox` VALUES(40, '', 'Rozin Tanveer khan is copying', 9, 0);
INSERT INTO `commentbox` VALUES(41, 'dsfsdf', 'dsdasd', 21, 0);
INSERT INTO `commentbox` VALUES(42, '', 'sdfsdf', 21, 0);

-- --------------------------------------------------------

--
-- Table structure for table `professionals`
--

CREATE TABLE `professionals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Contact_information` varchar(500) NOT NULL,
  `P_ImagePath` varchar(500) NOT NULL,
  `Type` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `professionals`
--

INSERT INTO `professionals` VALUES(1, 'md. Masud Sir', 'BEST OF HOUZZ 2012, 2013 and 2014: Seattle Architects Coates Design Architects performs work anywhere in the United States. We have a sterling reputation for offering innovative architectural and sustainable design services for a wide range of projects. We pride ourselves on consistently exceeding our client''s goals, on both large and small construction projects. ', 'New York, New England & Beyond Award Winning Designs  Architects & Building Designers Contact: James Crisp Location: 3788 Route 44 Millbrook, NY 12545 Typical Job Costs: $200,000 - $10,000,000', 'Engineers/civil-engineer.jpg', 'Engineer');
INSERT INTO `professionals` VALUES(2, 'md. Aadnan Rahman', 'We design new homes, additions, and renovations, and provide green solutions in New York, Massachusetts, Connecticut, Virginia and beyond.   Established in 1985 and located in the historic Hudson Valley, the Firm''s primary focus has been the creation of buildings that fit their site, historic context, and client needs, including energy conscious and green design solutions.', 'Dallas Area Landscape Architect Best of Houzz 2013-2015  Landscape Architects & Landscape Designers Contact: Harold Leidner Location: 1601 Surveyor Boulevard Carrollton, TX 75006', 'Engineers/Civil-Pictures-10.jpg', 'Engineer');
INSERT INTO `professionals` VALUES(3, 'md. Aadnan Rahman', 'Harold Leidner Landscape Architects specializes in the design and installation of exceptional residential properties and gardens that extend the outdoor living experience of our clients.   Our projects feature unique and creative design solutions that are crafted to the personal taste of our clients, their families and the modern lifestyle. We take pride in exceeding the expectations of our discriminating clientele in both personal service and the craftsmanship of our work.', 'phone number: 01955237727', 'Engineers/Gorazd-with-TIP-m01tuzvg0cn885nqflpbrrca1is62f1u4irr7ba2ew.jpg', 'Architecture');
INSERT INTO `professionals` VALUES(4, 'khalil', ' Miami Interior Designers,  Britto Charette Interior designs reflect the modern tastes and design demands of today’s discerning global clients. Our bilingual and well-traveled team brings the best global design innovations, luxurious finishes, cutting-edge trends in color and patterns, and trusted building materials to our discerning clients. Our offices in Miami''s vibrant Wynwood community and New York City allow us to help clients from around the world plan and develop their luxurious spaces. ', ' Interior Designers & Decorators Contact: Jay Britto Location: 310 NW 26th Street Miami, FL 33127 License Number: IB26001621', 'Engineers/Male-civil-engineer-working-at-a-construction-site.jpg', 'Designer');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Client_Name` varchar(500) NOT NULL,
  `Email` varchar(500) NOT NULL,
  `Product_ID` varchar(20) NOT NULL,
  `Payment_Method` varchar(500) NOT NULL,
  `Date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Product_ID` (`Product_ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` VALUES(1, 'sadsa', 'asdsa', '1', '654654', '2015-07-23 02:01:19');
INSERT INTO `purchases` VALUES(2, 'asdsa', 'sadsda', '', '884864', '2015-07-23 02:53:37');
INSERT INTO `purchases` VALUES(3, 'tfdg', 'fdgfdg', '', '65456456465', '2015-07-25 13:07:52');
INSERT INTO `purchases` VALUES(4, 'dsfsdf', 'sadfasasfas@gmail.com', '5', '56654685465465', '2015-07-25 13:10:25');
INSERT INTO `purchases` VALUES(5, 'sadasd', 'shafiqulislam561@gmal.com', '', '13213213', '2015-07-30 13:25:27');
INSERT INTO `purchases` VALUES(6, 'sadasd', 'shafiqulislam561@gmal.com', '', '13213213', '2015-07-30 13:30:30');
INSERT INTO `purchases` VALUES(7, 'sadasd', 'shafiqulislam561@gmal.com', '', '13213213', '2015-07-30 13:31:26');
INSERT INTO `purchases` VALUES(8, 'sadasd', 'shafiqulislam561@gmal.com', '', '13234', '2015-07-30 13:36:50');
INSERT INTO `purchases` VALUES(9, 'sadasd', 'shafiqulislam561@gmal.com', '', '132341', '2015-07-30 13:37:12');
INSERT INTO `purchases` VALUES(10, 'rozin', 'roabin567', '', '4356r76t8', '2015-07-30 15:15:06');
INSERT INTO `purchases` VALUES(11, 'toto', 'toto', '', '3245677', '2015-07-30 15:22:24');
INSERT INTO `purchases` VALUES(12, 'sdfds', 'sdfdsf', '', '234324', '2015-07-30 21:26:42');
INSERT INTO `purchases` VALUES(13, 'sdf', 'sdf@fass', '', '1123123', '2015-08-02 00:11:38');
INSERT INTO `purchases` VALUES(14, 'asdasd', 'asdasd', '', '2331234', '2015-08-02 12:13:23');

-- --------------------------------------------------------

--
-- Table structure for table `suggest`
--

CREATE TABLE `suggest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `suggest`
--

INSERT INTO `suggest` VALUES(1, 1, 1);
INSERT INTO `suggest` VALUES(2, 1, 2);
INSERT INTO `suggest` VALUES(3, 1, 2);
INSERT INTO `suggest` VALUES(4, 1, 2);
INSERT INTO `suggest` VALUES(5, 1, 1);
INSERT INTO `suggest` VALUES(6, 1, 1);
INSERT INTO `suggest` VALUES(7, 1, 1);
INSERT INTO `suggest` VALUES(8, 2, 1);
INSERT INTO `suggest` VALUES(9, 2, 1);
INSERT INTO `suggest` VALUES(10, 2, 1);
INSERT INTO `suggest` VALUES(11, 2, 1);
INSERT INTO `suggest` VALUES(12, 2, 1);
INSERT INTO `suggest` VALUES(13, 1, 1);
INSERT INTO `suggest` VALUES(14, 1, 1);
INSERT INTO `suggest` VALUES(15, 1, 1);
INSERT INTO `suggest` VALUES(16, 3, 1);
INSERT INTO `suggest` VALUES(17, 3, 1);
INSERT INTO `suggest` VALUES(18, 3, 1);
INSERT INTO `suggest` VALUES(19, 3, 1);
INSERT INTO `suggest` VALUES(20, 5, 1);
INSERT INTO `suggest` VALUES(21, 5, 1);
INSERT INTO `suggest` VALUES(22, 5, 1);
INSERT INTO `suggest` VALUES(23, 5, 1);
INSERT INTO `suggest` VALUES(24, 1, 1);
INSERT INTO `suggest` VALUES(25, 5, 1);
INSERT INTO `suggest` VALUES(26, 5, 1);
INSERT INTO `suggest` VALUES(27, 5, 1);
INSERT INTO `suggest` VALUES(28, 5, 1);
INSERT INTO `suggest` VALUES(29, 5, 1);
INSERT INTO `suggest` VALUES(30, 2, 1);
INSERT INTO `suggest` VALUES(31, 1, 1);
INSERT INTO `suggest` VALUES(32, 1, 1);
INSERT INTO `suggest` VALUES(33, 21, 1);
INSERT INTO `suggest` VALUES(34, 10, 1);
INSERT INTO `suggest` VALUES(35, 22, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `contactnumber` int(50) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `last_login` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(1, 1673235388, 'Fahim', 'Islam', 'shafiqulislam561@gmail.com', '', '19a06b5085ef662bcf6d8ac0d217d5a948887871', '2015-07-19 18:35:32');
INSERT INTO `users` VALUES(2, 2147483647, '', 'Khan', 'rozin@gmail.com', '', '89416a706bb9495d4ff52dfe321d2d27d3f3f4dd', '2015-07-19 18:37:33');
INSERT INTO `users` VALUES(5, 1, '', '1', 'sdadsd@hddfh.com', '', '6058f963e2f86fe2b42b90ca26972ed6b8ea1fc0', '2015-07-19 18:50:42');
INSERT INTO `users` VALUES(4, 454646465, '', 'Bhai', 'rozin1@gmail.com', '', 'fa96f7076d9f4dba7db731b052623274710a6047', '2015-07-19 18:39:51');
INSERT INTO `users` VALUES(6, 3, '', '1', 'sadsad@gmail.com', 'Male', '432b38a66b6dd988530c739d72ab8c7c13277148', '2015-07-19 18:58:12');
INSERT INTO `users` VALUES(7, 1955237727, 'Rozin', 'Khan', 'rozin2345@gmail.com', 'Male', '7c4a8d09ca3762af61e59520943dc26494f8941b', '2015-07-19 19:42:50');
INSERT INTO `users` VALUES(8, 2147483647, ' Fahim01', 'safsafas', 'sadfasasfas@gmail.com', 'Male', '37cbf5deb7acd0ebb58d0af02a05956c04ff008d', '2015-07-25 21:03:47');
INSERT INTO `users` VALUES(9, 2147483647, ' Fahim01', 'safsafas', 'sadfasasfas@gmail.com', 'Male', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '2015-07-25 21:04:49');
INSERT INTO `users` VALUES(10, 123123123, ' fssdfeswdf', 'xcxzczxc', 'asdsadsa@gamil.com', 'Male', '356a192b7913b04c54574d18c28d46e6395428ab', '2015-07-26 12:12:26');
INSERT INTO `users` VALUES(11, 1955237727, ' ert', 'ter', 'wer@gmail.com', 'Male', 'c2f94b9367dc8cdcd3dcf24677a094fff54baaa5', '2015-07-30 15:59:40');
INSERT INTO `users` VALUES(12, 1955237727, ' ert', 'ter', 'wer@gmail.com', 'Male', 'c2f94b9367dc8cdcd3dcf24677a094fff54baaa5', '2015-07-30 16:00:48');
INSERT INTO `users` VALUES(13, 1212, ' a', 'a', 'sdfdsfs@gamil.com', 'Male', '7a31f36b7b526dc02c733e629b34e9c065e69b0c', '2015-07-30 21:26:18');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
